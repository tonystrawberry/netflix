```bash
zip -r s3_trigger_aws_lambda_function.zip s3_trigger_aws_lambda_function.rb vendor
```
